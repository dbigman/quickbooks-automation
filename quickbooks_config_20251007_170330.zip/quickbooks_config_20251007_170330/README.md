# QuickBooks Order Exporter - Configuration Package

This package contains all IDE and development environment configurations for the QuickBooks Order Exporter project.

## What's Included

### .kiro/ - Kiro AI Assistant Configuration
- **hooks/**: Automated agent hooks for code review, testing, documentation
- **settings/**: MCP (Model Context Protocol) server configurations
- **steering/**: AI guidance rules and project standards (40+ rule files)

### .vscode/ - Visual Studio Code Settings
- **settings.json**: Editor configuration, Python settings, formatting rules

### .github/ - GitHub Actions Workflows
- **workflows/ci.yml**: Continuous integration pipeline
- **workflows/roo_rules.yml**: Roo AI validation workflow

### .roo/ - Roo AI Configuration
- **mcp.json**: MCP server settings for Roo AI

### .codex/ - Codex Configuration
- **config.toml**: Codex AI assistant settings

### .spec-workflow/ - Specification Workflow
- **approvals/**: Spec approval tracking
- **specs/**: Feature specifications
- **steering/**: Workflow guidance

### Root Configuration Files
- **.cursorrules**: Cursor AI editor rules
- **.gitignore**: Git ignore patterns
- **.python-version**: Python version specification
- **pyproject.toml**: Python project configuration
- **.env.example**: Environment variable template

## Installation

### Option 1: Extract to Existing Repository

```bash
# In your quickbooks-order-exporter repository
unzip quickbooks_config_YYYYMMDD_HHMMSS.zip

# Move contents to root
mv quickbooks_config_YYYYMMDD_HHMMSS/* .
mv quickbooks_config_YYYYMMDD_HHMMSS/.* . 2>/dev/null || true
rm -rf quickbooks_config_YYYYMMDD_HHMMSS
```

### Option 2: Fresh Setup

```bash
# Create new repository
git clone <your-repo-url>
cd quickbooks-order-exporter

# Extract both packages
unzip quickbooks_order_exporter_YYYYMMDD_HHMMSS.zip
unzip quickbooks_config_YYYYMMDD_HHMMSS.zip

# Merge contents
# (Follow detailed instructions in SETUP_GUIDE.md)
```

## Configuration Overview

### Kiro AI Assistant

The `.kiro/` directory contains comprehensive AI assistant configuration:

**Hooks** (6 automated workflows):
1. **auto-doc-generator**: Generates documentation for Python scripts
2. **auto-test-generator**: Creates test files for new code
3. **handoff-report-generator**: Creates knowledge transfer documents
4. **python-code-review**: Automated code quality checks
5. **quickbooks-qbxml-validator**: Validates QuickBooks qbXML code
6. **repo-standards-validation**: Ensures code follows project standards

**Steering Rules** (40+ files):
- Philosophy and coding principles
- Project context and architecture
- Task execution workflows
- AI collaboration guidelines
- Code quality standards
- Testing and validation
- Security best practices
- Documentation standards
- And much more...

### MCP (Model Context Protocol) Servers

Configured in `.kiro/settings/mcp.json` and `.roo/mcp.json`:

- **fetch**: Web content retrieval
- **context7**: Documentation and context
- **playwright**: Browser automation
- **odoo**: Odoo ERP integration
- **excel**: Excel file manipulation

### VS Code Settings

`.vscode/settings.json` includes:
- Python interpreter configuration
- Formatting settings (Black, 80 char lines)
- Linting configuration (Flake8)
- Type checking (MyPy)
- Test discovery settings

### GitHub Actions

`.github/workflows/` includes:
- **ci.yml**: Runs tests, linting, type checking on push/PR
- **roo_rules.yml**: Validates code against Roo AI rules

## Customization

### Update Odoo Credentials

Edit `.env` (create from `.env.example`):
```env
ODOO_URL=http://your-server:8069
ODOO_DATABASE=YourDatabase
ODOO_USERNAME=your.email@company.com
ODOO_PASSWORD=YourPassword
```

### Modify AI Steering Rules

Edit files in `.kiro/steering/` to customize AI behavior:
- `product.md`: Project description and goals
- `tech.md`: Technology stack and tools
- `code style.md`: Coding standards
- `testing validation.md`: Test requirements

### Configure MCP Servers

Edit `.kiro/settings/mcp.json` to add/remove MCP servers:
```json
{
  "mcpServers": {
    "your-server": {
      "command": "uvx",
      "args": ["your-package@latest"],
      "disabled": false
    }
  }
}
```

### Adjust VS Code Settings

Edit `.vscode/settings.json` for your preferences:
```json
{
  "python.defaultInterpreterPath": "${workspaceFolder}/venv/bin/python",
  "editor.rulers": [80],
  "python.formatting.provider": "black"
}
```

## Features Enabled

### AI-Powered Development
✅ Automated code review on file save  
✅ Auto-generated documentation  
✅ Test generation assistance  
✅ QuickBooks qbXML validation  
✅ Repository standards enforcement  

### Code Quality
✅ Black formatting (80 char lines)  
✅ Flake8 linting  
✅ MyPy type checking  
✅ Pytest test framework  
✅ Pre-commit hooks ready  

### CI/CD
✅ GitHub Actions workflows  
✅ Automated testing on push  
✅ Code quality checks  
✅ Roo AI validation  

### Documentation
✅ Comprehensive steering rules  
✅ Project standards documented  
✅ AI guidance for common tasks  
✅ Architecture documentation  

## Troubleshooting

### MCP Servers Not Working

1. Install `uv` package manager:
   ```bash
   # macOS/Linux
   curl -LsSf https://astral.sh/uv/install.sh | sh
   
   # Windows
   powershell -c "irm https://astral.sh/uv/install.ps1 | iex"
   ```

2. Restart your IDE (Kiro, Cursor, VS Code)

3. Check MCP server status in IDE settings

### Kiro Hooks Not Triggering

1. Verify `.kiro/hooks/` files have correct permissions
2. Check hook configuration in Kiro settings
3. Ensure file patterns match your code files

### GitHub Actions Failing

1. Check workflow files in `.github/workflows/`
2. Verify Python version matches `.python-version`
3. Ensure all dependencies in `requirements.txt`

## File Structure

```
.
├── .kiro/
│   ├── hooks/              # 6 automated agent hooks
│   ├── settings/           # MCP server configuration
│   ├── specs/              # Feature specifications
│   └── steering/           # 40+ AI guidance rules
├── .vscode/
│   └── settings.json       # VS Code configuration
├── .github/
│   └── workflows/          # CI/CD pipelines
│       ├── ci.yml
│       └── roo_rules.yml
├── .roo/
│   └── mcp.json           # Roo AI MCP settings
├── .codex/
│   └── config.toml        # Codex configuration
├── .spec-workflow/
│   ├── approvals/         # Spec approvals
│   ├── specs/             # Specifications
│   └── steering/          # Workflow guidance
├── .cursorrules           # Cursor AI rules
├── .gitignore            # Git ignore patterns
├── .python-version       # Python version
├── .env.example          # Environment template
└── pyproject.toml        # Python project config
```

## Next Steps

1. **Review Configuration**: Check all config files match your needs
2. **Update Credentials**: Edit `.env` with your Odoo settings
3. **Test MCP Servers**: Verify MCP servers are working
4. **Run Tests**: Execute `pytest tests/` to verify setup
5. **Commit Changes**: Add configuration to git

## Support

For configuration issues:
1. Check IDE-specific documentation (Kiro, Cursor, VS Code)
2. Review MCP server logs
3. Verify Python environment is activated
4. Ensure all dependencies are installed

## Version Information

- **Package Version**: 1.0.0
- **Python**: 3.8+
- **Compatible IDEs**: Kiro, Cursor, VS Code, Roo
- **Status**: Production Ready ✅

---

**Created**: October 7, 2025  
**Purpose**: Development environment configuration  
**Compatibility**: QuickBooks Order Exporter v1.0.0
